package examples;

import com.vmware.sqlfire.procedure.*;
import java.sql.*;

public class MergeSortProcedure {
  
  static final String queryString = "<local> SELECT * FROM EMP.PARTITIONTESTTABLE ORDER BY SECONDID";
  
  public static void mergeSort(ResultSet[] outResults, ProcedureExecutionContext context)
  throws SQLException {
    
    Connection cxn = context.getConnection();
    Statement stmt = cxn.createStatement();
    ResultSet rs = stmt.executeQuery(queryString);
    outResults[0] = rs;
    // Do not close the connection since this would also
    // close the result set.
  }

}
