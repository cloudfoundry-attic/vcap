package examples;

import com.vmware.sqlfire.procedure.*;

import java.sql.*;
import java.util.*;

public class MergeSortProcessor implements ProcedureResultProcessor {
  
  private ProcedureProcessorContext context;
  
  /**
   * Initialize this processor.
   */
  public void init(ProcedureProcessorContext context) {
    this.context = context;
  }
  
  
  /**
   * Provide the out parameters for this procedure to the client as an
   * Object[].
   *
   * @throws InterruptedException if interrupted while waiting to receive
   *         data.
   */
  public Object[] getOutParameters() throws InterruptedException {
    throw new AssertionError("this procedure has no out parameters");    
  }
  
  
  /**
   * Provide the next row for result set number resultSetNumber.
   * The processor should do whatever processing is required on the
   * incoming data to provide the next row.
   *
   * Return the next row of the result set specified by resultSetNumber,
   * or null if there are no more rows in this result set.
   *
   * @param resultSetNumber the 1-based result set number for the row being
   *        requested
   * @throws InterruptedException if interrupted while waiting to receive
   *         data.
   *
   *
   * @throws InterruptedException if interrupted while waiting to receive
   *         data.
   */
  public List<Object> getNextResultRow(int resultSetNumber)
  throws InterruptedException {
    // this procedure deals with only first result set
    assert resultSetNumber == 0: "unexpected resultSetNumber="
        + resultSetNumber;
    IncomingResultSet[] inSets = this.context.getIncomingResultSets(0);
    List<Object> lesserRow = null;
    Comparator<List<Object>> cmp = getComparator();

    IncomingResultSet setWithLeastRow = null;
    for (IncomingResultSet inSet : inSets) {
      List<Object> nextRow = inSet.waitPeekRow(); // blocks until row is available
      if (nextRow == IncomingResultSet.END_OF_RESULTS) {
        // no more rows in this incoming results
        continue;
      }
      // find the least row so far
      if (lesserRow == null || cmp.compare(nextRow, lesserRow) <= 0) {
        lesserRow = nextRow;
        setWithLeastRow = inSet;
      }
    }

    if (setWithLeastRow != null) {
      // consume the lesserRow by removing lesserRow from the incoming result
      // set
      List<Object> takeRow = setWithLeastRow.takeRow();
      assert takeRow == lesserRow;
    }

    // if lesserRow is null, then there are no more rows in any incoming
    // results
    return lesserRow;
  }

  /**
   * Called by SQLFire when this statement is closed.
   */
  public void close() {
    this.context = null;
  }

  /** Return an appropriate Comparator for sorting the rows */
  private Comparator<List<Object>> getComparator() {
    return new Comparator<List<Object>>() {
      public int compare(List<Object> a1, List<Object> a2) {
        if ((Integer)a1.get(1) < (Integer)a2.get(1)) {
          return -1;
        }
        else if ((Integer)a1.get(1) > (Integer)a2.get(1)) {
          return 1;
        }
        return 0;
      }
    };
  }
}
